class Question < ApplicationRecord
  belongs_to :enneagram_number
end
