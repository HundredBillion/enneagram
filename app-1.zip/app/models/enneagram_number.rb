class EnneagramNumber < ApplicationRecord
  has_many :questions
end
