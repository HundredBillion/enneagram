class Page < ApplicationRecord
end
