//select

questions_to_compare = [
  // document.getElementById("question57score").innerHTML,
  // document.getElementById("question58score").innerHTML,
  // document.getElementById("question59score").innerHTML,
  // document.getElementById("question60score").innerHTML,
  // document.getElementById("question61score").innerHTML,
  // document.getElementById("question62score").innerHTML,
  // document.getElementById("question63score").innerHTML,
  // document.getElementById("question64score").innerHTML,
  // document.getElementById("question65score").innerHTML,
]

//build

//if any number in array is equal, force model to pop up asking them to pick one answer as a higher answer
console.log(questions_to_compare)