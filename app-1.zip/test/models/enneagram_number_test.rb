require 'test_helper'

class EnneagramNumberTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
