require 'test_helper'

class EnneagramScoreTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
